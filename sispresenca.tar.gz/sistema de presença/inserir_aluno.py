import sqlite3

conn = sqlite3.connect('database.db')
cursor = conn.cursor()

cursor.execute('''
INSERT INTO alunos (nome, matricula, turma, email_pais, senha)
VALUES (?, ?, ?, ?, ?)
''', ('João Silva', '2024001', '3º Ano', 'pais@email.com', '123456'))

conn.commit()
conn.close()
print("Aluno de teste criado!")