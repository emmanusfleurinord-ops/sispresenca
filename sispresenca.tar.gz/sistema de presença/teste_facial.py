import cv2
import os
from deepface import DeepFace

# --- PASSO 1: CARREGAR AS FOTOS ---
pasta_rostos = 'rostos_alunos'
nomes_conhecidos = []

print("Carregando as fotos dos alunos...")
for arquivo in os.listdir(pasta_rostos):
    if arquivo.endswith(('.jpg', '.jpeg', '.png')):
        nomes_conhecidos.append(os.path.splitext(arquivo)[0])
        print(f" - Rosto do {arquivo} registrado!")

if not nomes_conhecidos:
    print("ERRO: Nenhuma foto encontrada na pasta 'rostos_alunos'.")
    exit()

# --- PASSO 2: LIGAR A CÂMERA ---
video_capture = cv2.VideoCapture(0)
print("\nCâmera ligada! Aperte 'q' na janela de vídeo para sair.\n")

while True:
    ret, frame = video_capture.read()
    if not ret:
        print("Não foi possível acessar a câmera.")
        break

    try:
        # A DeepFace compara o rosto da câmera com as fotos da pasta
        resultados = DeepFace.find(
            img_path=frame, 
            db_path=pasta_rostos, 
            enforce_detection=False,
            silent=True,
            model_name="VGG-Face"
        )
        
        nome = "Desconhecido"
        if resultados and len(resultados[0]) > 0:
            # Pega o nome do arquivo da foto que deu match
            caminho_match = resultados[0].iloc[0]['identity']
            nome = os.path.splitext(os.path.basename(caminho_match))[0]
            print(f"👀 Aluno detectado: {nome}")

    except Exception as e:
        nome = "Analisando..."
    
    # Desenha o nome na tela
    cv2.putText(frame, nome, (50, 50), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
    
    # Mostra o vídeo
    cv2.imshow('Reconhecimento Facial - Teste', frame)

    # Fecha se apertar 'q'
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

video_capture.release()
cv2.destroyAllWindows()