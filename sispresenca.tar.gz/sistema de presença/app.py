import os
import sqlite3
import secrets
import time
import hashlib
import csv
import json
from datetime import datetime, date, timedelta
from functools import wraps
from io import BytesIO

from flask import (
    Flask, render_template, request, redirect, url_for,
    session, flash, g, send_file, abort, Response
)
import qrcode
from werkzeug.utils import secure_filename

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "troque-esta-chave-em-producao")

UPLOAD_FOLDER = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'static', 'uploads')
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif', 'pdf'}
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

DATABASE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "database.db")
QR_ROTATION_SECONDS = 60

# ---------------------------------------------------------------------------
# QR Code
# ---------------------------------------------------------------------------
def _current_qr_token():
    janela = int(time.time()) // QR_ROTATION_SECONDS
    base = f"{app.secret_key}:{janela}".encode("utf-8")
    return hashlib.sha256(base).hexdigest()[:24]

def _token_valido(token: str) -> bool:
    if not token:
        return False
    janela = int(time.time()) // QR_ROTATION_SECONDS
    for j in (janela, janela - 1):
        esperado = hashlib.sha256(f"{app.secret_key}:{j}".encode("utf-8")).hexdigest()[:24]
        if secrets.compare_digest(esperado, token):
            return True
    return False

# ---------------------------------------------------------------------------
# Configurações de Horário
# ---------------------------------------------------------------------------
def _get_config_horarios(db):
    configs = {}
    rows = db.execute("SELECT chave, valor FROM configuracoes").fetchall()
    for r in rows:
        configs[r["chave"]] = r["valor"]
    return configs

def _calcular_status_checkin(db):
    configs = _get_config_horarios(db)
    inicio = configs.get('hora_inicio', '06:00')
    normal_fim = configs.get('hora_normal_fim', '06:50')
    atraso_fim = configs.get('hora_atraso_fim', '12:45')
    agora = datetime.now().strftime("%H:%M")
    
    if inicio <= agora <= normal_fim:
        return ('liberado', 'normal', agora)
    elif normal_fim < agora <= atraso_fim:
        return ('liberado', 'atrasado', agora)
    else:
        return ('bloqueado', None, agora)

# ---------------------------------------------------------------------------
# ENVIO DE E-MAIL (Simulação)
# ---------------------------------------------------------------------------
def _enviar_email_pais(destinatario, nome_aluno, data, hora, tipo="presenca"):
    try:
        if tipo == "falta":
            print(f"[SIMULAÇÃO] E-mail enviado para {destinatario} avisando que {nome_aluno} FALTOU no dia {data}.")
        else:
            print(f"[SIMULAÇÃO] E-mail enviado para {destinatario} avisando que {nome_aluno} chegou às {hora} do dia {data}.")
        time.sleep(0.1)
        return True
    except Exception as e:
        print(f"[ERRO] Falha ao enviar para {destinatario}: {e}")
        return False

# ---------------------------------------------------------------------------
# Banco de dados + migração
# ---------------------------------------------------------------------------
def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DATABASE)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
    return g.db

@app.teardown_appcontext
def close_db(exception=None):
    db = g.pop("db", None)
    if db is not None:
        db.close()

def init_db():
    db = sqlite3.connect(DATABASE)
    db.execute("PRAGMA foreign_keys = ON")

    db.executescript(
        """
        CREATE TABLE IF NOT EXISTS series (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome TEXT NOT NULL UNIQUE,
            nivel TEXT NOT NULL CHECK (nivel IN ('fundamental','medio'))
        );
        CREATE TABLE IF NOT EXISTS turmas (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome TEXT NOT NULL,
            serie_id INTEGER NOT NULL,
            ano_letivo INTEGER NOT NULL,
            FOREIGN KEY (serie_id) REFERENCES series(id) ON DELETE CASCADE,
            UNIQUE (nome, serie_id, ano_letivo)
        );
        CREATE TABLE IF NOT EXISTS alunos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome TEXT NOT NULL,
            matricula TEXT NOT NULL UNIQUE,
            turma TEXT,
            turma_id INTEGER,
            email_pais TEXT,
            senha TEXT NOT NULL,
            foto TEXT,
            FOREIGN KEY (turma_id) REFERENCES turmas(id) ON DELETE SET NULL
        );
        CREATE TABLE IF NOT EXISTS presencas (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            aluno_id INTEGER NOT NULL,
            data TEXT NOT NULL,
            hora TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'presente',
            FOREIGN KEY(aluno_id) REFERENCES alunos(id) ON DELETE CASCADE
        );
        CREATE TABLE IF NOT EXISTS notificacoes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            aluno_id INTEGER NOT NULL,
            email_pais TEXT NOT NULL,
            data_presenca TEXT NOT NULL,
            hora_presenca TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'pendente',
            tipo TEXT NOT NULL DEFAULT 'presenca',
            data_envio TEXT,
            FOREIGN KEY(aluno_id) REFERENCES alunos(id) ON DELETE CASCADE
        );
        CREATE TABLE IF NOT EXISTS configuracoes (
            chave TEXT PRIMARY KEY,
            valor TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS justificativas (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            aluno_id INTEGER NOT NULL,
            data_falta TEXT NOT NULL,
            motivo TEXT NOT NULL,
            arquivo TEXT,
            status TEXT NOT NULL DEFAULT 'pendente',
            data_envio TEXT NOT NULL,
            FOREIGN KEY(aluno_id) REFERENCES alunos(id) ON DELETE CASCADE
        );
        CREATE TABLE IF NOT EXISTS saidas_antecipadas (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            aluno_id INTEGER NOT NULL,
            motivo TEXT NOT NULL,
            hora_solicitacao TEXT NOT NULL,
            data_solicitacao TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'pendente',
            hora_aprovacao TEXT,
            FOREIGN KEY(aluno_id) REFERENCES alunos(id) ON DELETE CASCADE
        );
        """
    )

    # Migrações seguras
    colunas_alunos = [r[1] for r in db.execute("PRAGMA table_info(alunos)").fetchall()]
    novas_colunas = {
        "turma_id": "INTEGER REFERENCES turmas(id) ON DELETE SET NULL",
        "foto": "TEXT",
        "cpf": "TEXT",
        "endereco": "TEXT",
        "responsavel": "TEXT",
        "idade": "INTEGER",
        "deficiencia": "TEXT",
        "genero": "TEXT"
    }
    for coluna, tipo in novas_colunas.items():
        if coluna not in colunas_alunos:
            db.execute(f"ALTER TABLE alunos ADD COLUMN {coluna} {tipo}")

    colunas_notif = [r[1] for r in db.execute("PRAGMA table_info(notificacoes)").fetchall()]
    if "tipo" not in colunas_notif:
        db.execute("ALTER TABLE notificacoes ADD COLUMN tipo TEXT NOT NULL DEFAULT 'presenca'")

    db.commit()

    total_series = db.execute("SELECT COUNT(*) FROM series").fetchone()[0]
    if total_series == 0:
        series_padrao = [
            ("1º ano - Fundamental", "fundamental"), ("2º ano - Fundamental", "fundamental"),
            ("3º ano - Fundamental", "fundamental"), ("4º ano - Fundamental", "fundamental"),
            ("5º ano - Fundamental", "fundamental"), ("6º ano - Fundamental", "fundamental"),
            ("7º ano - Fundamental", "fundamental"), ("8º ano - Fundamental", "fundamental"),
            ("9º ano - Fundamental", "fundamental"),
            ("1º ano - Médio", "medio"), ("2º ano - Médio", "medio"), ("3º ano - Médio", "medio"),
        ]
        db.executemany("INSERT INTO series (nome, nivel) VALUES (?, ?)", series_padrao)
        db.commit()

    configs_padrao = {
        'hora_inicio': '06:00',
        'hora_normal_fim': '06:50',
        'hora_atraso_fim': '12:45'
    }
    for chave, valor in configs_padrao.items():
        if not db.execute("SELECT * FROM configuracoes WHERE chave = ?", (chave,)).fetchone():
            db.execute("INSERT INTO configuracoes (chave, valor) VALUES (?, ?)", (chave, valor))
    db.commit()
    
    db.close()

# ---------------------------------------------------------------------------
# Auth
# ---------------------------------------------------------------------------
def login_required(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        if not session.get("aluno_id"):
            flash("Faça login para continuar.", "erro")
            return redirect(url_for("login"))
        return f(*args, **kwargs)
    return wrapper

def admin_required(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        if not session.get("is_admin"):
            flash("Acesso restrito ao administrador.", "erro")
            return redirect(url_for("login"))
        return f(*args, **kwargs)
    return wrapper

# ---------------------------------------------------------------------------
# Rotas de autenticação
# ---------------------------------------------------------------------------
@app.route("/", methods=["GET"])
def index():
    if session.get("aluno_id"):
        return redirect(url_for("checkin"))
    if session.get("is_admin"):
        return redirect(url_for("admin"))
    return redirect(url_for("login"))

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        matricula_digitada = request.form.get("matricula", "").strip()
        senha = request.form.get("senha", "")

        # 1. Verifica se é o ADMIN
        if matricula_digitada.lower() == "admin" and senha == os.environ.get("ADMIN_PASSWORD", "admin123"):
            session.clear()
            session["is_admin"] = True
            return redirect(url_for("admin"))

        # 2. Verifica se é ALUNO (limpando os pontinhos do CPF para buscar no banco)
        db = get_db()
        
        # Remove pontos, traços e espaços do que foi digitado
        busca_limpa = matricula_digitada.replace(".", "").replace("-", "").replace(" ", "")
        
        # Busca no banco onde o CPF/Matrícula (também limpo) bata
        aluno = db.execute(
            """
            SELECT * FROM alunos 
            WHERE (REPLACE(REPLACE(REPLACE(matricula, '.', ''), '-', ''), ' ', '') = ? 
               OR REPLACE(REPLACE(REPLACE(cpf, '.', ''), '-', ''), ' ', '') = ?) 
            AND senha = ?
            """, 
            (busca_limpa, busca_limpa, senha)
        ).fetchone()

        if aluno:
            session.clear()
            session["aluno_id"] = aluno["id"]
            session["aluno_nome"] = aluno["nome"]
            session["aluno_matricula"] = aluno["matricula"]
            session["aluno_foto"] = aluno["foto"]
            return redirect(url_for("checkin"))

        flash("Matrícula ou senha inválidos.", "erro")
    return render_template("login.html")

@app.route("/logout")
def logout():
    session.clear()
    flash("Sessão encerrada.", "ok")
    return redirect(url_for("login"))

# ---------------------------------------------------------------------------
# Rotas do aluno
# ---------------------------------------------------------------------------
@app.route("/checkin", methods=["GET", "POST"])
@login_required
def checkin():
    db = get_db()
    aluno_id = session["aluno_id"]
    hoje = date.today().isoformat()

    ja_registrado = db.execute(
        "SELECT * FROM presencas WHERE aluno_id = ? AND data = ?",
        (aluno_id, hoje),
    ).fetchone()

    if request.method == "POST":
        if ja_registrado:
            flash("Você já tem um registro para hoje.", "erro")
        else:
            permitido, tipo, hora_atual = _calcular_status_checkin(db)
            
            if not permitido:
                configs = _get_config_horarios(db)
                flash(f"O check-in está encerrado por hoje. O portão fechou às {configs.get('hora_atraso_fim')}.", "erro")
            else:
                agora = datetime.now()
                status_presenca = "presente_atrasado" if tipo == "atrasado" else "presente"
                
                db.execute(
                    "INSERT INTO presencas (aluno_id, data, hora, status) VALUES (?, ?, ?, ?)",
                    (aluno_id, agora.date().isoformat(), agora.strftime("%H:%M:%S"), status_presenca),
                )
                aluno = db.execute("SELECT * FROM alunos WHERE id = ?", (aluno_id,)).fetchone()
                if aluno["email_pais"]:
                    db.execute(
                        "INSERT INTO notificacoes (aluno_id, email_pais, data_presenca, hora_presenca, status, tipo) VALUES (?, ?, ?, ?, 'pendente', 'presenca')",
                        (aluno_id, aluno["email_pais"], agora.date().isoformat(), agora.strftime("%H:%M:%S"))
                    )
                db.commit()
                
                if tipo == "atrasado":
                    flash("Presença registrada, mas você está ATRASADO. Passe pela secretaria.", "erro")
                else:
                    flash("Presença registrada no horário normal!", "ok")
        return redirect(url_for("checkin"))

    permitido, tipo, hora_atual = _calcular_status_checkin(db)
    configs = _get_config_horarios(db)
    
    falta_justificada = False
    if ja_registrado and ja_registrado['status'] == 'justificada':
        falta_justificada = True
    
    saida_hoje = db.execute(
        "SELECT * FROM saidas_antecipadas WHERE aluno_id = ? AND data_solicitacao = ?",
        (aluno_id, hoje)
    ).fetchone()
    
    return render_template(
        "checkin.html", 
        ja_registrado=ja_registrado, 
        falta_justificada=falta_justificada,
        permitido=permitido,
        tipo=tipo,
        configs=configs,
        saida_hoje=saida_hoje
    )

@app.route("/historico")
@login_required
def historico():
    db = get_db()
    aluno_id = session["aluno_id"]
    registros = db.execute(
        """
        SELECT p.id, p.data, p.hora, p.status,
               a.nome AS aluno_nome, a.matricula AS aluno_matricula
        FROM presencas p
        JOIN alunos a ON a.id = p.aluno_id
        WHERE p.aluno_id = ?
        ORDER BY p.data DESC, p.hora DESC
        """,
        (aluno_id,),
    ).fetchall()
    return render_template("historico.html", registros=registros, aluno_id=aluno_id, aluno_nome=session.get("aluno_nome"), total=len(registros))

@app.route("/perfil", methods=["GET", "POST"])
@login_required
def perfil():
    db = get_db()
    aluno_id = session["aluno_id"]
    aluno = db.execute("SELECT * FROM alunos WHERE id = ?", (aluno_id,)).fetchone()
    
    if request.method == "POST":
        foto = request.files.get("foto")
        if foto and foto.filename != '':
            if allowed_file(foto.filename):
                ext = foto.filename.rsplit('.', 1)[1].lower()
                nome_arquivo = f"foto_{aluno_id}.{ext}"
                caminho = os.path.join(app.config['UPLOAD_FOLDER'], nome_arquivo)
                foto.save(caminho)
                db.execute("UPDATE alunos SET foto = ? WHERE id = ?", (nome_arquivo, aluno_id))
                session["aluno_foto"] = nome_arquivo
                db.commit()
                flash("Foto atualizada!", "ok")
            else:
                flash("Formato inválido.", "erro")
                return redirect(url_for("perfil"))
                
        senha_atual = request.form.get("senha_atual", "")
        nova_senha = request.form.get("nova_senha", "")
        confirmar_senha = request.form.get("confirmar_senha", "")
        
        if senha_atual or nova_senha or confirmar_senha:
            if not (senha_atual and nova_senha and confirmar_senha):
                flash("Preencha todos os campos de senha.", "erro")
            elif aluno["senha"] != senha_atual:
                flash("Senha atual incorreta.", "erro")
            elif nova_senha != confirmar_senha:
                flash("As senhas não batem.", "erro")
            elif len(nova_senha) < 4:
                flash("Mínimo de 4 caracteres.", "erro")
            else:
                db.execute("UPDATE alunos SET senha = ? WHERE id = ?", (nova_senha, aluno_id))
                db.commit()
                flash("Senha alterada!", "ok")
                
        return redirect(url_for("perfil"))
            
    return render_template("perfil.html", aluno=aluno)

@app.route("/justificar_falta", methods=["POST"])
@login_required
def justificar_falta():
    db = get_db()
    aluno_id = session["aluno_id"]
    data_falta = request.form.get("data_falta")
    motivo = request.form.get("motivo", "").strip()
    
    if not data_falta or not motivo:
        flash("Preencha a data e o motivo.", "erro")
        return redirect(url_for("perfil"))
        
    ja_justificado = db.execute("SELECT * FROM justificativas WHERE aluno_id = ? AND data_falta = ?", (aluno_id, data_falta)).fetchone()
    
    if ja_justificado:
        flash("Você já enviou uma justificativa para esta data.", "erro")
        return redirect(url_for("perfil"))

    arquivo = request.files.get("arquivo")
    nome_arquivo = None
    if arquivo and arquivo.filename != '':
        if allowed_file(arquivo.filename):
            ext = arquivo.filename.rsplit('.', 1)[1].lower()
            nome_arquivo = f"atestado_{aluno_id}_{data_falta}.{ext}"
            caminho = os.path.join(app.config['UPLOAD_FOLDER'], nome_arquivo)
            arquivo.save(caminho)
        else:
            flash("Formato de arquivo inválido.", "erro")
            return redirect(url_for("perfil"))

    db.execute(
        "INSERT INTO justificativas (aluno_id, data_falta, motivo, arquivo, status, data_envio) VALUES (?, ?, ?, ?, 'pendente', ?)",
        (aluno_id, data_falta, motivo, nome_arquivo, datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
    )
    db.commit()
    flash("Justificativa enviada com sucesso! Aguarde a aprovação.", "ok")
    return redirect(url_for("perfil"))

@app.route("/solicitar_saida", methods=["POST"])
@login_required
def solicitar_saida():
    db = get_db()
    aluno_id = session["aluno_id"]
    motivo = request.form.get("motivo", "").strip()
    hoje = date.today().isoformat()
    
    if not motivo:
        flash("Descreva o motivo da saída.", "erro")
        return redirect(url_for("checkin"))
        
    ja_solicitado = db.execute("SELECT * FROM saidas_antecipadas WHERE aluno_id = ? AND data_solicitacao = ?", (aluno_id, hoje)).fetchone()
    if ja_solicitado:
        flash("Você já possui uma solicitação de saída para hoje.", "erro")
        return redirect(url_for("checkin"))
        
    presenca_hoje = db.execute("SELECT * FROM presencas WHERE aluno_id = ? AND data = ?", (aluno_id, hoje)).fetchone()
    if not presenca_hoje:
        flash("Você precisa ter registrado presença hoje para solicitar a saída.", "erro")
        return redirect(url_for("checkin"))

    agora = datetime.now()
    db.execute(
        "INSERT INTO saidas_antecipadas (aluno_id, motivo, data_solicitacao, hora_solicitacao, status) VALUES (?, ?, ?, ?, 'pendente')",
        (aluno_id, motivo, hoje, agora.strftime("%H:%M:%S"))
    )
    db.commit()
    flash("Solicitação de saída enviada! Aguarde a liberação da secretaria.", "ok")
    return redirect(url_for("checkin"))

# ---------------------------------------------------------------------------
# QR Code
# ---------------------------------------------------------------------------
@app.route("/qr", methods=["GET"])
@admin_required
def qr_display():
    token = _current_qr_token()
    return render_template("qr_display.html", token=token, rotacao=QR_ROTATION_SECONDS)

@app.route("/qr/<token>", methods=["GET", "POST"])
def qr_checkin(token):
    if not _token_valido(token):
        return render_template("qr_resultado.html", titulo="QR Code expirado", mensagem="Este QR Code expirou.", sucesso=False), 400

    if not session.get("aluno_id"):
        session["qr_token_pendente"] = token
        flash("Faça login para concluir o check-in.", "ok")
        return redirect(url_for("login"))

    db = get_db()
    aluno_id = session["aluno_id"]
    hoje = date.today().isoformat()

    ja = db.execute("SELECT * FROM presencas WHERE aluno_id = ? AND data = ?", (aluno_id, hoje)).fetchone()

    if ja:
        return render_template("qr_resultado.html", titulo="Já registrado", mensagem=f"Olá, {session.get('aluno_nome')}! Seu dia já está registrado.", sucesso=True)

    permitido, tipo, hora_atual = _calcular_status_checkin(db)
    if not permitido:
        configs = _get_config_horarios(db)
        return render_template("qr_resultado.html", titulo="Fora do horário", mensagem=f"O portão fechou às {configs.get('hora_atraso_fim')}.", sucesso=False)

    agora = datetime.now()
    status_presenca = "presente_atrasado" if tipo == "atrasado" else "presente"
    
    db.execute("INSERT INTO presencas (aluno_id, data, hora, status) VALUES (?, ?, ?, ?)", (aluno_id, agora.date().isoformat(), agora.strftime("%H:%M:%S"), status_presenca))
    aluno = db.execute("SELECT * FROM alunos WHERE id = ?", (aluno_id,)).fetchone()
    if aluno["email_pais"]:
        db.execute("INSERT INTO notificacoes (aluno_id, email_pais, data_presenca, hora_presenca, status, tipo) VALUES (?, ?, ?, ?, 'pendente', 'presenca')", (aluno_id, aluno["email_pais"], agora.date().isoformat(), agora.strftime("%H:%M:%S")))
    
    db.commit()
    session.pop("qr_token_pendente", None)
    
    msg_extra = " (Atrasado)" if tipo == "atrasado" else ""
    return render_template("qr_resultado.html", titulo="Presença registrada!", mensagem=f"Olá, {session.get('aluno_nome')}! Presença registrada às {agora.strftime('%H:%M:%S')}{msg_extra}.", sucesso=True)

@app.route("/qr.png")
@admin_required
def qr_image():
    token = _current_qr_token()
    url_checkin = f"{request.host_url.rstrip('/')}/qr/{token}"
    img = qrcode.make(url_checkin, box_size=10, border=2)
    buf = BytesIO()
    img.save(buf, format="PNG")
    buf.seek(0)
    return send_file(buf, mimetype="image/png")

# ---------------------------------------------------------------------------
# Admin: painel
# ---------------------------------------------------------------------------
@app.route("/admin")
@admin_required
def admin():
    db = get_db()
    hoje = date.today().isoformat()

    total_alunos = db.execute("SELECT COUNT(*) AS c FROM alunos").fetchone()["c"]
    total_presencas = db.execute("SELECT COUNT(*) AS c FROM presencas").fetchone()["c"]
    total_turmas = db.execute("SELECT COUNT(*) AS c FROM turmas").fetchone()["c"]
    total_series = db.execute("SELECT COUNT(*) AS c FROM series").fetchone()["c"]
    total_notif_pendentes = db.execute("SELECT COUNT(*) AS c FROM notificacoes WHERE status = 'pendente'").fetchone()["c"]
    total_just_pendentes = db.execute("SELECT COUNT(*) AS c FROM justificativas WHERE status = 'pendente'").fetchone()["c"]
    total_saidas_pendentes = db.execute("SELECT COUNT(*) AS c FROM saidas_antecipadas WHERE status = 'pendente'").fetchone()["c"]

    labels_grafico = []
    dados_grafico = []
    for i in range(6, -1, -1):
        dia = date.today() - timedelta(days=i)
        dia_str = dia.isoformat()
        labels_grafico.append(dia.strftime("%d/%m"))
        qtd = db.execute("SELECT COUNT(*) AS c FROM presencas WHERE data = ?", (dia_str,)).fetchone()["c"]
        dados_grafico.append(qtd)

    labels_json = json.dumps(labels_grafico)
    dados_json = json.dumps(dados_grafico)

    presentes_hoje_ids = {row["aluno_id"] for row in db.execute("SELECT aluno_id FROM presencas WHERE data = ?", (hoje,)).fetchall()}
    alunos = db.execute("SELECT * FROM alunos ORDER BY nome").fetchall()
    faltaram_hoje = [a for a in alunos if a["id"] not in presentes_hoje_ids]

    registros = db.execute(
        """
        SELECT p.id, p.data, p.hora, p.status, a.nome, a.matricula, a.turma
        FROM presencas p JOIN alunos a ON a.id = p.aluno_id
        ORDER BY p.data DESC, p.hora DESC LIMIT 200
        """
    ).fetchall()

    return render_template(
        "admin.html",
        total_alunos=total_alunos, total_presencas=total_presencas,
        total_turmas=total_turmas, total_series=total_series,
        total_notif_pendentes=total_notif_pendentes,
        total_just_pendentes=total_just_pendentes,
        total_saidas_pendentes=total_saidas_pendentes,
        faltaram_hoje=faltaram_hoje, registros=registros, hoje=hoje,
        labels_json=labels_json, dados_json=dados_json
    )

@app.route("/admin/notificar_falta/<int:aluno_id>", methods=["POST"])
@admin_required
def admin_notificar_falta(aluno_id):
    db = get_db()
    aluno = db.execute("SELECT * FROM alunos WHERE id = ?", (aluno_id,)).fetchone()
    hoje = date.today().isoformat()
    
    if aluno and aluno["email_pais"]:
        ja_notificado = db.execute(
            "SELECT id FROM notificacoes WHERE aluno_id = ? AND data_presenca = ? AND tipo = 'falta'",
            (aluno_id, hoje)
        ).fetchone()
        
        if not ja_notificado:
            db.execute(
                "INSERT INTO notificacoes (aluno_id, email_pais, data_presenca, hora_presenca, status, tipo) VALUES (?, ?, ?, '00:00:00', 'pendente', 'falta')",
                (aluno_id, aluno["email_pais"], hoje)
            )
            db.commit()
            flash(f"Notificação de falta para {aluno['nome']} adicionada à fila.", "ok")
        else:
            flash("Os pais deste aluno já foram notificados hoje.", "erro")
    else:
        flash("Este aluno não possui e-mail dos pais cadastrado.", "erro")
        
    return redirect(url_for("admin"))

# ---------------------------------------------------------------------------
# Admin: Crachá Digital
# ---------------------------------------------------------------------------
@app.route("/admin/cracha/<int:aluno_id>")
@admin_required
def admin_cracha(aluno_id):
    db = get_db()
    aluno = db.execute(
        """
        SELECT a.*, t.nome AS turma_nome, t.ano_letivo, s.nome AS serie_nome, s.nivel
        FROM alunos a
        LEFT JOIN turmas t ON t.id = a.turma_id
        LEFT JOIN series s ON s.id = t.serie_id
        WHERE a.id = ?
        """, (aluno_id,)
    ).fetchone()
    
    if not aluno:
        abort(404)
        
    return render_template("cracha.html", aluno=aluno)

# ---------------------------------------------------------------------------
# Admin: Saídas Antecipadas
# ---------------------------------------------------------------------------
@app.route("/admin/saidas")
@admin_required
def admin_saidas():
    db = get_db()
    saidas = db.execute(
        """
        SELECT s.*, a.nome AS aluno_nome, a.matricula, a.turma
        FROM saidas_antecipadas s
        JOIN alunos a ON a.id = s.aluno_id
        ORDER BY s.status ASC, s.data_solicitacao DESC, s.hora_solicitacao DESC
        """
    ).fetchall()
    return render_template("admin_saidas.html", saidas=saidas)

@app.route("/admin/saidas/<int:saida_id>/aprovar", methods=["POST"])
@admin_required
def admin_saida_aprovar(saida_id):
    db = get_db()
    saida = db.execute("SELECT * FROM saidas_antecipadas WHERE id = ?", (saida_id,)).fetchone()
    
    if saida and saida["status"] == "pendente":
        agora = datetime.now()
        db.execute(
            "UPDATE saidas_antecipadas SET status = 'aprovada', hora_aprovacao = ? WHERE id = ?",
            (agora.strftime("%H:%M:%S"), saida_id)
        )
        
        presenca = db.execute(
            "SELECT id FROM presencas WHERE aluno_id = ? AND data = ?",
            (saida["aluno_id"], saida["data_solicitacao"])
        ).fetchone()
        
        if presenca:
            db.execute("UPDATE presencas SET status = 'saiu_mais_cedo' WHERE id = ?", (presenca["id"],))
            
        db.commit()
        flash("Saída aprovada! O aluno foi liberado.", "ok")
    else:
        flash("Solicitação já processada ou não encontrada.", "erro")
        
    return redirect(url_for("admin_saidas"))

# ---------------------------------------------------------------------------
# Admin: Justificativas
# ---------------------------------------------------------------------------
@app.route("/admin/justificativas")
@admin_required
def admin_justificativas():
    db = get_db()
    justificativas = db.execute(
        """
        SELECT j.*, a.nome AS aluno_nome, a.matricula, a.turma
        FROM justificativas j
        JOIN alunos a ON a.id = j.aluno_id
        ORDER BY j.status ASC, j.data_falta DESC
        """
    ).fetchall()
    return render_template("admin_justificativas.html", justificativas=justificativas)

@app.route("/admin/justificativas/<int:just_id>/aprovar", methods=["POST"])
@admin_required
def admin_justificar_aprovar(just_id):
    db = get_db()
    just = db.execute("SELECT * FROM justificativas WHERE id = ?", (just_id,)).fetchone()
    
    if just and just["status"] == "pendente":
        db.execute("UPDATE justificativas SET status = 'aprovada' WHERE id = ?", (just_id,))
        
        ja_existe = db.execute("SELECT id FROM presencas WHERE aluno_id = ? AND data = ?", (just["aluno_id"], just["data_falta"])).fetchone()
        
        if not ja_existe:
            db.execute("INSERT INTO presencas (aluno_id, data, hora, status) VALUES (?, ?, ?, ?)", (just["aluno_id"], just["data_falta"], "00:00:00", "justificada"))
        else:
            db.execute("UPDATE presencas SET status = 'justificada' WHERE id = ?", (ja_existe["id"],))
            
        db.commit()
        flash("Justificativa aprovada. Falta abonada!", "ok")
    else:
        flash("Justificativa já processada.", "erro")
        
    return redirect(url_for("admin_justificativas"))

# ---------------------------------------------------------------------------
# Admin: Configurações e Notificações
# ---------------------------------------------------------------------------
@app.route("/admin/configuracoes", methods=["GET", "POST"])
@admin_required
def admin_configuracoes():
    db = get_db()
    if request.method == "POST":
        inicio = request.form.get("hora_inicio", "")
        normal_fim = request.form.get("hora_normal_fim", "")
        atraso_fim = request.form.get("hora_atraso_fim", "")
        
        if inicio and normal_fim and atraso_fim:
            db.execute("UPDATE configuracoes SET valor = ? WHERE chave = 'hora_inicio'", (inicio,))
            db.execute("UPDATE configuracoes SET valor = ? WHERE chave = 'hora_normal_fim'", (normal_fim,))
            db.execute("UPDATE configuracoes SET valor = ? WHERE chave = 'hora_atraso_fim'", (atraso_fim,))
            db.commit()
            flash("Horários atualizados!", "ok")
        else:
            flash("Preencha todos os horários.", "erro")
        return redirect(url_for("admin_configuracoes"))
        
    configs = _get_config_horarios(db)
    return render_template("admin_config.html", configs=configs)

@app.route("/admin/notificacoes")
@admin_required
def admin_notificacoes():
    db = get_db()
    notificacoes = db.execute(
        """
        SELECT n.*, a.nome AS aluno_nome, a.matricula
        FROM notificacoes n JOIN alunos a ON a.id = n.aluno_id
        ORDER BY n.status ASC, n.data_presenca DESC, n.hora_presenca DESC LIMIT 200
        """
    ).fetchall()
    return render_template("admin_notificacoes.html", notificacoes=notificacoes)

@app.route("/admin/disparar_notificacoes", methods=["POST"])
@admin_required
def admin_disparar_notificacoes():
    db = get_db()
    pendentes = db.execute("SELECT * FROM notificacoes WHERE status = 'pendente'").fetchall()
    sucesso = 0
    falha = 0
    
    for n in pendentes:
        aluno = db.execute("SELECT nome FROM alunos WHERE id = ?", (n["aluno_id"],)).fetchone()
        nome_aluno = aluno["nome"] if aluno else "Aluno"
        
        tipo_notif = n["tipo"] if "tipo" in n.keys() else "presenca"
        
        if _enviar_email_pais(n["email_pais"], nome_aluno, n["data_presenca"], n["hora_presenca"], tipo_notif):
            db.execute("UPDATE notificacoes SET status = 'enviado', data_envio = ? WHERE id = ?", (datetime.now().strftime("%Y-%m-%d %H:%M:%S"), n["id"]))
            sucesso += 1
        else:
            falha += 1
    db.commit()
    
    if sucesso > 0: flash(f"{sucesso} e-mail(s) enviado(s)!", "ok")
    if falha > 0: flash(f"{falha} e-mail(s) falharam.", "erro")
    if sucesso == 0 and falha == 0: flash("Nenhuma pendente.", "ok")
    return redirect(url_for("admin_notificacoes"))

# ---------------------------------------------------------------------------
# Admin: Séries, Turmas, Alunos e CSV
# ---------------------------------------------------------------------------
@app.route("/admin/series", methods=["GET", "POST"])
@admin_required
def admin_series():
    db = get_db()
    if request.method == "POST":
        nome = request.form.get("nome", "").strip()
        nivel = request.form.get("nivel", "").strip()
        if not nome or nivel not in ("fundamental", "medio"):
            flash("Informe nome e nível válido.", "erro")
        else:
            try:
                db.execute("INSERT INTO series (nome, nivel) VALUES (?, ?)", (nome, nivel))
                db.commit()
                flash(f"Série '{nome}' cadastrada.", "ok")
            except sqlite3.IntegrityError:
                flash("Já existe essa série.", "erro")
        return redirect(url_for("admin_series"))

    series = db.execute("SELECT * FROM series ORDER BY nivel DESC, nome").fetchall()
    return render_template("admin_series.html", series=series)

@app.route("/admin/series/<int:serie_id>/excluir", methods=["POST"])
@admin_required
def admin_serie_excluir(serie_id):
    db = get_db()
    db.execute("DELETE FROM series WHERE id = ?", (serie_id,))
    db.commit()
    flash("Série removida.", "ok")
    return redirect(url_for("admin_series"))

@app.route("/admin/turmas", methods=["GET", "POST"])
@admin_required
def admin_turmas():
    db = get_db()
    if request.method == "POST":
        nome = request.form.get("nome", "").strip()
        serie_id = request.form.get("serie_id", "").strip()
        ano_letivo = request.form.get("ano_letivo", "").strip()
        if not nome or not serie_id or not ano_letivo.isdigit():
            flash("Preencha os campos válidos.", "erro")
        else:
            try:
                db.execute("INSERT INTO turmas (nome, serie_id, ano_letivo) VALUES (?, ?, ?)", (nome, int(serie_id), int(ano_letivo)))
                db.commit()
                flash(f"Turma '{nome}' cadastrada.", "ok")
            except sqlite3.IntegrityError:
                flash("Já existe essa turma.", "erro")
        return redirect(url_for("admin_turmas"))

    turmas = db.execute(
        """
        SELECT t.id, t.nome, t.ano_letivo, s.nome AS serie_nome, s.nivel,
               (SELECT COUNT(*) FROM alunos a WHERE a.turma_id = t.id) AS total_alunos
        FROM turmas t JOIN series s ON s.id = t.serie_id
        ORDER BY t.ano_letivo DESC, s.nivel DESC, s.nome, t.nome
        """
    ).fetchall()
    series = db.execute("SELECT * FROM series ORDER BY nivel DESC, nome").fetchall()
    ano_atual = date.today().year
    return render_template("admin_turmas.html", turmas=turmas, series=series, ano_atual=ano_atual)

@app.route("/admin/turmas/<int:turma_id>/excluir", methods=["POST"])
@admin_required
def admin_turma_excluir(turma_id):
    db = get_db()
    db.execute("DELETE FROM turmas WHERE id = ?", (turma_id,))
    db.commit()
    flash("Turma removida.", "ok")
    return redirect(url_for("admin_turmas"))

def _turmas_para_form():
    db = get_db()
    return db.execute(
        """
        SELECT t.id, t.nome, t.ano_letivo, s.nome AS serie_nome, s.nivel
        FROM turmas t JOIN series s ON s.id = t.serie_id
        ORDER BY t.ano_letivo DESC, s.nivel DESC, s.nome, t.nome
        """
    ).fetchall()

@app.route("/admin/alunos", methods=["GET"])
@admin_required
def admin_alunos():
    db = get_db()
    alunos = db.execute(
        """
        SELECT a.*, t.nome AS turma_nome, t.ano_letivo, s.nome AS serie_nome, s.nivel
        FROM alunos a
        LEFT JOIN turmas t ON t.id = a.turma_id
        LEFT JOIN series s ON s.id = t.serie_id
        ORDER BY s.nivel DESC, s.nome, t.nome, a.nome
        """
    ).fetchall()
    return render_template("admin_alunos.html", alunos=alunos)

@app.route("/admin/cadastrar", methods=["GET", "POST"])
@admin_required
def cadastrar_aluno():
    db = get_db()
    if request.method == "POST":
        nome = request.form.get("nome", "").strip()
        cpf = request.form.get("cpf", "").strip()
        turma_id = request.form.get("turma_id", "").strip()
        email_pais = request.form.get("email_pais", "").strip()
        senha = request.form.get("senha", "").strip()
        
        endereco = request.form.get("endereco", "").strip()
        responsavel = request.form.get("responsavel", "").strip()
        idade = request.form.get("idade", "").strip()
        deficiencia = request.form.get("deficiencia", "").strip()
        genero = request.form.get("genero", "").strip()

        if not (nome and cpf and turma_id and senha):
            flash("Preencha todos os campos obrigatórios (Nome, CPF, Turma, Senha).", "erro")
            return redirect(url_for("cadastrar_aluno"))

        turma = db.execute("SELECT t.nome AS turma_nome, s.nome AS serie_nome FROM turmas t JOIN series s ON s.id = t.serie_id WHERE t.id = ?", (int(turma_id),)).fetchone()
        if not turma:
            flash("Turma inválida.", "erro")
            return redirect(url_for("cadastrar_aluno"))

        turma_texto = f"{turma['serie_nome']} - {turma['turma_nome']}"
        
        try:
            db.execute(
                """
                INSERT INTO alunos (nome, matricula, cpf, turma, turma_id, email_pais, senha, endereco, responsavel, idade, deficiencia, genero) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, 
                (nome, cpf, cpf, turma_texto, int(turma_id), email_pais, senha, endereco, responsavel, idade, deficiencia, genero)
            )
            db.commit()
            flash(f"Aluno {nome} cadastrado com sucesso.", "ok")
            return redirect(url_for("admin_alunos"))
        except sqlite3.IntegrityError:
            flash("CPF/Matrícula já cadastrada.", "erro")
            return redirect(url_for("cadastrar_aluno"))

    return render_template("cadastrar_aluno.html", turmas=_turmas_para_form())

@app.route("/admin/alunos/<int:aluno_id>/editar", methods=["GET", "POST"])
@admin_required
def admin_aluno_editar(aluno_id):
    db = get_db()
    aluno = db.execute("SELECT * FROM alunos WHERE id = ?", (aluno_id,)).fetchone()
    if not aluno:
        abort(404)

    if request.method == "POST":
        nome = request.form.get("nome", "").strip()
        cpf = request.form.get("cpf", "").strip()
        turma_id = request.form.get("turma_id", "").strip()
        email_pais = request.form.get("email_pais", "").strip()
        nova_senha = request.form.get("senha", "").strip()
        
        endereco = request.form.get("endereco", "").strip()
        responsavel = request.form.get("responsavel", "").strip()
        idade = request.form.get("idade", "").strip()
        deficiencia = request.form.get("deficiencia", "").strip()
        genero = request.form.get("genero", "").strip()

        if not (nome and cpf and turma_id):
            flash("Preencha nome, CPF e turma.", "erro")
            return redirect(url_for("admin_aluno_editar", aluno_id=aluno_id))

        turma = db.execute("SELECT t.nome AS turma_nome, s.nome AS serie_nome FROM turmas t JOIN series s ON s.id = t.serie_id WHERE t.id = ?", (int(turma_id),)).fetchone()
        if not turma:
            flash("Turma inválida.", "erro")
            return redirect(url_for("admin_aluno_editar", aluno_id=aluno_id))

        turma_texto = f"{turma['serie_nome']} - {turma['turma_nome']}"
        
        try:
            if nova_senha:
                db.execute(
                    """
                    UPDATE alunos 
                    SET nome=?, matricula=?, cpf=?, turma=?, turma_id=?, email_pais=?, senha=?, endereco=?, responsavel=?, idade=?, deficiencia=?, genero=? 
                    WHERE id=?
                    """, 
                    (nome, cpf, cpf, turma_texto, int(turma_id), email_pais, nova_senha, endereco, responsavel, idade, deficiencia, genero, aluno_id)
                )
            else:
                db.execute(
                    """
                    UPDATE alunos 
                    SET nome=?, matricula=?, cpf=?, turma=?, turma_id=?, email_pais=?, endereco=?, responsavel=?, idade=?, deficiencia=?, genero=? 
                    WHERE id=?
                    """, 
                    (nome, cpf, cpf, turma_texto, int(turma_id), email_pais, endereco, responsavel, idade, deficiencia, genero, aluno_id)
                )
            db.commit()
            flash("Dados atualizados.", "ok")
            return redirect(url_for("admin_alunos"))
        except sqlite3.IntegrityError:
            flash("CPF/Matrícula já usada por outro aluno.", "erro")
            return redirect(url_for("admin_aluno_editar", aluno_id=aluno_id))

    return render_template("cadastrar_aluno.html", aluno=aluno, turmas=_turmas_para_form())

@app.route("/admin/alunos/<int:aluno_id>/excluir", methods=["POST"])
@admin_required
def admin_aluno_excluir(aluno_id):
    db = get_db()
    db.execute("DELETE FROM alunos WHERE id = ?", (aluno_id,))
    db.commit()
    flash("Aluno removido.", "ok")
    return redirect(url_for("admin_alunos"))

@app.route("/admin/presenca/<int:presenca_id>/excluir", methods=["POST"])
@admin_required
def admin_presenca_excluir(presenca_id):
    db = get_db()
    db.execute("DELETE FROM presencas WHERE id = ?", (presenca_id,))
    db.commit()
    flash("Registro excluído.", "ok")
    return redirect(url_for("admin"))

@app.route("/admin/exportar_csv")
@admin_required
def admin_exportar_csv():
    db = get_db()
    registros = db.execute(
        "SELECT p.data, p.hora, p.status, a.nome, a.matricula, a.turma FROM presencas p JOIN alunos a ON a.id = p.aluno_id ORDER BY p.data DESC, p.hora DESC"
    ).fetchall()

    def generate():
        yield '\ufeff'
        yield 'Data;Hora;Nome;Matricula;Turma;Status\n'
        for r in registros:
            yield f"{r['data']};{r['hora']};{r['nome']};{r['matricula']};{r['turma'] or ''};{r['status']}\n"

    return Response(generate(), mimetype="text/csv", headers={"Content-Disposition": "attachment; filename=relatorio_presencas.csv"})

# ---------------------------------------------------------------------------
# Bootstrap
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    init_db()
    app.run(host="0.0.0.0", port=8000, debug=True)