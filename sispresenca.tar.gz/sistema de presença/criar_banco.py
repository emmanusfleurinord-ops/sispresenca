import sqlite3

# Conecta (ou cria) o banco
conn = sqlite3.connect('database.db')
cursor = conn.cursor()

# Tabela de alunos
cursor.execute('''
CREATE TABLE IF NOT EXISTS alunos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT NOT NULL,
    matricula TEXT UNIQUE NOT NULL,
    turma TEXT,
    email_pais TEXT NOT NULL,
    senha TEXT NOT NULL
)
''')

# Tabela de presenças
cursor.execute('''
CREATE TABLE IF NOT EXISTS presencas (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    aluno_id INTEGER NOT NULL,
    data TEXT NOT NULL,
    hora TEXT NOT NULL,
    status TEXT NOT NULL,
    FOREIGN KEY (aluno_id) REFERENCES alunos (id)
)
''')

conn.commit()
conn.close()

print("Banco de dados criado com sucesso!")