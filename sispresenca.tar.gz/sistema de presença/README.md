# 🎓 Sistema de Controle de Presença Escolar

Um sistema web completo para gestão de frequência escolar, desenvolvido para modernizar o registro de presenças em escolas. O projeto conta com check-in via QR Code rotativo, painel administrativo com gráficos, exportação de relatórios e envio de notificações aos pais.

## 🚀 Tecnologias Utilizadas

O projeto foi construído utilizando as seguintes ferramentas:

*   **Backend:** Python 3.10 + Flask
*   **Banco de Dados:** SQLite (nativo do Python)
*   **Frontend:** HTML5, CSS3, JavaScript (Vanilla)
*   **Bibliotecas Python:** 
    *   `qrcode` (Geração de QR Codes)
    *   `werkzeug` (Segurança e Upload de arquivos)
*   **Bibliotecas JS:** 
    *   `Chart.js` (Gráficos do painel)

## ⚙️ Como Executar o Projeto

Siga os passos abaixo para rodar o sistema na sua máquina local.

### 1. Pré-requisitos
Certifique-se de ter o Python instalado na sua máquina.

### 2. Instalar as dependências
No terminal, navegue até a pasta do projeto e instale as bibliotecas necessárias:
```bash
pip install flask qrcode[pil] werkzeug