import qrcode

link = "http://127.0.0.1:8000/checkin"

img = qrcode.make(link)

img.save("qrcode_presenca.png")

print("QR Code gerado com sucesso!")